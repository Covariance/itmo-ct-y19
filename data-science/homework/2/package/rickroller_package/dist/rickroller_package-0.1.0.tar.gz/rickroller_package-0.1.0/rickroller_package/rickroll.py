import numpy as np

def rick() -> str:
    return 'roll: ' + str(np.random.randint(low=1, high=21))

def roll() -> str:
    return 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'