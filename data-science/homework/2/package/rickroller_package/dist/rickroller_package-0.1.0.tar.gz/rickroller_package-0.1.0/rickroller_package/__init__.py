"""
rickroller package

Package that rolls and ricks and conflicts.
"""

__version__ = "0.1.0"
__author__ = 'Pavel Martynov'
__credits__ = 'Rick Astley'

import rickroller_package.rickroll
